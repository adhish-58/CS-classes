/*****************************************************************************
 * FILE: tank.cpp --- Lab 9 animated version                                 *
 * CLASS PROVIDED: mixing_tank (part of namespace CS256_CMGLab2)             *
 *    See tank.h for documentation                                           *
 *  AUTHOR: J. Rogers                                                        *
 *  MODIFIED:  N. Sommer (April 2003) --- Added display() and position       *
 *  MODIFIED:  C. Kern (April 2004) --- Added animation                      *
 *  Modified: Adhish Adhikari: I added two functions, get_status and set_status  *
 *                                                                           *
 * LIBRARIES:  cassert for assert( )                                         *
 *             CarnegieMellonGraphics.h for graphics                         *
 *                                                                           *
 * NAMESPACE  CS256_CMGLab2                                                  *
 *                                                                           *
 *****************************************************************************/
#include <cassert>
#include "tank.h"

using namespace std;

namespace CS256_CMGLab2
{

  mixing_tank::mixing_tank( )
  {
    max_capacity = 100; vol_A = vol_B = 0; x = y = 0; 
    current_status = mixing_tank::STATIC;  //Adhish: initializing current_status
  }
  
  mixing_tank::mixing_tank( string initname, double capacity,
                            int initx, int inity )
    { 
      name = initname;
      max_capacity = capacity; 
      vol_A = vol_B = 0;
      x = initx;
      y = inity;
      current_status = mixing_tank::STATIC;  //Adhish: initialize
                                             //current_status as static
    }
  
  // MODIFICATION MEMBER FUNCTIONS

/****************************************************************************
 *   void add_A( double quantity )                                           *
 *     Preconditions: quantity is non-negative                               *
 *                    quantity is no greater than remaining capacity         *
 *     Postconditions: quantity of liquid `A' has been added to tank         *
 ****************************************************************************/
  void mixing_tank::add_A( double quantity )
    { 
      assert ( quantity >= 0 );
      assert ( quantity <= get_space( ) ); 
      vol_A += quantity;
    }
  
/****************************************************************************
 *   void add_B( double quantity )                                           *
 *     Preconditions: quantity is non-negative                               *
 *                    quantity is no greater than remaining capacity         *
 *     Postconditions: quantity of liquid `A' has been added to tank         *
 ****************************************************************************/
  void mixing_tank::add_B( double quantity )
    { 
      assert ( quantity >= 0 );
      assert ( quantity <= get_space( ) ); 
      vol_B += quantity;
    }
  
/****************************************************************************
 *   double draw( double quantity );                                         *
 *     Preconditions: quantity is non-negative                               *
 *     Postconditions: if quantity is no greater than the current volume     *
 *                       then quantity of the mixed liquid has been removed  *
 *                       from the tank.  Otherwise the tank has been emptied *
 ****************************************************************************/
  double mixing_tank::draw( double quantity )
    {
      assert( quantity >= 0 );

      if ( quantity > 0 )
        {
          if ( quantity > get_volume( ) )
            {
              quantity = get_volume( );
              vol_A = vol_B = 0;
            }
          else
            {
              double quant_A = ( get_mix( ) * quantity );
              vol_A -= quant_A;
              vol_B -= ( quantity - quant_A );
            }
        }
      
      return quantity;
    }

  void mixing_tank::set_status( status_type new_status)
  {
    current_status = new_status;  //Adhish: Set current status as new status
  }

  // CONSTANT MEMBER FUNCTIONS
  double mixing_tank::get_space( ) const
    {
      return (max_capacity - get_volume( ) );
    }
  
/****************************************************************************
 *   double get_volume( )                                                    *
 *     Preconditions: None                                                   *
 *     Postconditions: 0 <= return value <= capacity of tank                 *
 *                     Return value is volume of mixed liquid in tank        *
 ****************************************************************************/
  double mixing_tank::get_volume( ) const
    {
      double volume = vol_A + vol_B;
      if (volume > max_capacity)
        volume = max_capacity;
      return ( volume );
      //      return ( vol_A + vol_B);
    }
  
/****************************************************************************
 *   double get_mix( )                                                        *
 *     Preconditions: tank is not empty                                      *
 *     Postconditions: 0.0 <= return value <= 1.0                            *
 *                     Return value is proportion of A in tank               *
 ****************************************************************************/
  double mixing_tank::get_mix( ) const
    {
      assert ( !is_empty( ) );
      return ( vol_A / get_volume( ) );
    }
  
/****************************************************************************
 *   bool is_empty( )                                                        *
 *     Preconditions: None                                                   *
 *     Postconditions: Returns true iff tank is empty                        *
 ****************************************************************************/
  bool mixing_tank::is_empty( ) const
    {
      return ( get_volume( ) == 0.0 );
    }

  mixing_tank::status_type mixing_tank::get_status( ) const
  {
    return (current_status);  //Adhish: returns the current status
  }

  void mixing_tank::display( Window& w ) const
  {
    Font arial(Font::ROMAN, 15);
    Font arialsmall(Font::ROMAN, 12);

    // clear the tank's are by drawing a black rectangle
    w.drawRectangleFilled(Style(Color::BLACK), x+0, y+0, x+320, y+480);
    
    // draw tank status
    w.drawText( Style(Color::WHITE), arial, x+75, y+20, name);
    w.drawText( Style(Color::WHITE), arialsmall, x+75, y+40, "Volume:" );
    w.drawText( Style(Color::WHITE), arialsmall, x+75, y+60,
                "Proportion of A:");
    w.drawText( Style(Color::WHITE), arialsmall, x+75, y+80,
                "Space remaining:");
    if( is_empty() )
      w.drawText( Style(Color::WHITE), arialsmall, x+135, y+40, "empty" );
    else
      {
        w.drawText( Style(Color::WHITE), arialsmall, x+135, y+40,
                    w.numberToString(get_volume(), 0) );
        w.drawText( Style(Color::WHITE), arialsmall, x+205, y+60,
                    w.numberToString(get_mix(), 2) );
        w.drawText( Style(Color::WHITE), arialsmall, x+210, y+80,
                    w.numberToString(get_space(), 0) );
      }

    // draw tank liquid
    if ( !is_empty() )
      w.drawRectangleFilled( Style(Color(int( (1.0 - get_mix())*255 ), 0,
                                         int(get_mix() * 255))),
                             x+75, y+int(450 - get_volume()*.6),
                             x+275, y+450);
    
    // draw tank
    w.drawLine( Style(Color::GREEN, 3), x+75,
                y + int( 450 - max_capacity*.6 ), x+75, y+450);
    w.drawLine( Style(Color::GREEN, 3), x+75, y+450, x+275, y+450);
    w.drawLine( Style(Color::GREEN, 3), x+275,
                y + int( 450 - max_capacity*.6), x+275, y+450);

  }
  
}
