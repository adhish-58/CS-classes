/**************************************************************************
 * FILE: tankpuzzle.cpp           Lab 9 Animated version
 * AUTHOR: Ian Kelly (1/22/01)
 * MODIFIED: J. Rogers (27/Feb/01)
 *    --- Mostly just moved some comments around and added some prompting
 * MODIFIED: Nate Sommer (Feb 03)
 *    --- Added CMU graphics
 * MODIFIED: C. Kern (April 2004) --- Added animation 
 * MODIFIED: J. Rogers (Mar 07) Updated for new CMUgfx library
 * Modified: Adhish Adhikari -- changed the intro info, -- added loops in int
 * main for keyboard events.
 *
 * This program emulates two mixing tanks which may be successively filled
 * with two different liquids, drained into each other, or emptied.  
 * The puzzle part is to do this in such a way to achieve a desired mixture.  
 *
 * The user's object is to achieve in either tank a mixture such that the
 * proportion of liquid A in the tank is equal to DESIRED_MIX.
 *
 * The first prompt asks which tank the user wishes to work with for this
 * command. Valid responses are '1' or '2'. The user may also type 'q' to
 * quit the program.
 *
 * The second prompt asks what command to perform. Valid responses are:
 *     'a' -- fill the tank up with liquid A
 *	'b' -- fill the tank up with liquid B
 *	'e' -- empty the tank
 *	'p' -- pour the contents of the tank into the other tank
 *
 * When filling a tank, the liquid added to the tank will be mixed with
 * anything that is already in the tank.
 * When pouring a tank into the other tank, any liquid that does not fit in
 * the receiving tank will remain behind.
 * 
 * LIBRARIES:
 *  <cassert>   //provides assert
 *  <cstdlib>   // provides EXIT_SUCCESS
 *  <iostream>  // provides cout & cin
 *  <cmath>     // provides fabs
 *  "tank.h"    // Provides mixing_tank
 **************************************************************************/
#include <cassert>
#include <cstdlib>
#include <iostream>
#include <cmath>
#include "CarnegieMellonGraphics.h"
#include "tank.h"
#include <unistd.h>

using namespace std;
using namespace CS256_CMGLab2; // namespace of mixing_tank class

/****************************************************************************
 * WINDOW PARAMETERS
 ****************************************************************************/
const int WIDTH(640);  // Window width
const int HEIGHT(640); // Window height
const int INITX(100);  // X pos of origin in screen
const int INITY(100);  // Y pos of origin in screen
const int LMIX_X(275); // Left side of Mix label
const int LMIX_Y(500); // Bottom of Mix label
const int MBLK_L(275); // Left side of Mix Block
const int MBLK_R(375); // Right side of Mix Block
const int MBLK_T(520); // Top of Mix Block
const int MBLK_B(620); // Bottom of Mix Block

const Font helvet(Font::HELVETICA, 18);
const Font roman(Font::ROMAN, 15);

const double INCREMENT(5.0);   // Animation increment
const int ANIM_SPEED = 17;     // Animation pause in msecs


/****************************************************************************
 * Function: void init_display( Window& window )                            *
 *                                                                          *
 * Draws a black background on window and clears display list               *
 ****************************************************************************/
void init_display( Window& w )
{
  w.erase();
}

/****************************************************************************
 * Function: void draw_target( Window& window, const Font& font )           *
 *                                                                          *
 * Draws a labeled box continaing the color of the desired mix.             *
 ****************************************************************************/
void draw_target( Window& w, const Font& font )
{
  w.drawText( Style(Color::WHITE), font, LMIX_X, LMIX_Y, "Target mix:" );
  w.drawRectangleOutline( Style(Color::GREEN, 3), 
                          MBLK_L, MBLK_T, MBLK_R, MBLK_B);
  // Leave 1 pixel outline
  w.drawRectangleFilled( Style(Color(194, 0, 61)), 
                         MBLK_L+1, MBLK_T+1, MBLK_R-1, MBLK_B-1);
}

/****************************************************************************
 * Function: void displayTanks(mixing_tank& tank, mixing_tank& other,       * 
 *  	                        Window& window, const Font& targetfont )    *
 * Postcondition: window has been erased, both tanks and and the target     *
 *                have been drawn in the back buffer                        *  
 *                Does not reDraw                                           *
 ****************************************************************************/
void displayTanks(mixing_tank& tank, mixing_tank& other,  
                  Window& window, const Font& targetfont )
{
  window.erase();
  tank.display( window );
  other.display( window );
  draw_target( window, targetfont);
}
 

/**************************************************************************
 * Function: void fill_A( mixing_tank& tank )
 * Adds INCREMENT of liquid A to tank
 * 
 * Postcondition: Up to INCREMENT quantity of liquid A has been added
 **************************************************************************/
void fill_A( mixing_tank& tank )
{
  if (tank.get_space() - INCREMENT < 0)
    tank.add_A( tank.get_space() );
  else
    tank.add_A( INCREMENT );
}

/**************************************************************************
 * Function: void fill_B( mixing_tank& tank )
 * Adds INCREMENT of liquid B to tank
 * 
 * Postcondition: Up to INCREMENT quantity of liquid B has been added
 **************************************************************************/
void fill_B( mixing_tank& tank )
{
  if (tank.get_space() - INCREMENT < 0 )
    tank.add_B( tank.get_space() );
  else
    tank.add_B( INCREMENT );
}

/**************************************************************************
 * Function: void empty( mixing_tank& tank )
 * Removes INCREMENT from tank
 *
 * Postcondition: Up to INCREMENT quantity of liquid has been removed
 **************************************************************************/
void empty( mixing_tank& tank )
{
  tank.draw( INCREMENT );
}

/**************************************************************************
 * Function: void pour( mixing_tank& source, mixing_tank& destination )
 * Pours INCREMENT of contents of source into destination
 *
 * Postconditions: Up to INCREMENT has been transferred from source to 
 *                 destination, but not more that the total quantity in
 *                 source and not more than the total space in destination
 *
 * Libraries: cassert
 **************************************************************************/
void pour( mixing_tank& source, mixing_tank& destination )
{
  if (source.is_empty()) 
      return;

  double amount_to_pour = source.get_volume();
  if ( amount_to_pour > INCREMENT)
    amount_to_pour = INCREMENT;

  if( amount_to_pour > destination.get_space() )
    amount_to_pour = destination.get_space();
  
  double amount_A = amount_to_pour * source.get_mix();
  double amount_B = amount_to_pour - amount_A;
  
  destination.add_A( amount_A );
  
  if ( amount_B > destination.get_space( ) )
    amount_B = destination.get_space( );
  
  destination.add_B( amount_B );
      
  source.draw( amount_to_pour );
    
}

/**************************************************************************
 * Function: void print_status( const mixing_tank& t1, const mixing_tank& t2,
 *                              const double DESIRED_MIX )
 * Displays the status of the mixing tanks
 *
 * Precondition: Output is at beginning of line.
 * Postcondition: Status of t1 and t2 and the desired mix has been printed to
 *                cout followed by a newline
 * Libraries: iostream
 **************************************************************************/
void print_status( const mixing_tank& t1, const mixing_tank& t2, 
		   const double DESIRED_MIX )
{
  cout << "Tank 1: " << endl;
  
  if( t1.is_empty() )
    cout << "It is empty.  Capacity: " << t1.get_space() << endl;
  else
    cout << "  Volume: " << t1.get_volume() << " Proportion of A: "
	 << t1.get_mix() << " Space Remaining: " << t1.get_space() << endl;
  
  cout << "Tank 2: " << endl;
  
  if( t2.is_empty() )
    cout << "It is empty.  Capacity: " << t2.get_space() << endl;
  else
    cout << "  Volume: " << t2.get_volume() << " Proportion of A: "
	 << t2.get_mix() << " Space Remaining: " << t2.get_space() << endl;
  
  cout << "Desired Mix: " << DESIRED_MIX << endl;
}

/**************************************************************************
 * Function: bool check_victory( const mixing_tank& t1, const mixing_tank& t2,
 *                             const double DESIRED_MIX, const double PRECISION)
 * Checks to see if either t1 or t2 has DESIRED_MIX
 *
 * Preconditions: 0 <= DESIRED_MIX <= 1
 *                0 <= PRECISION <= 1
 * Postconditions: Returns true if either t1 or t2 has a mix of DESIRED_MIX
 *                 within a precision of PRECISION.
 *		  Otherwise returns false.
 * Libraries: cmath
 *              ---  double fabs( double x ) returns absolute value of x
 **************************************************************************/
bool check_victory( const mixing_tank& t1, const mixing_tank& t2,
		    const double DESIRED_MIX, const double PRECISION )
{
  return( !t1.is_empty() 
          && fabs( t1.get_mix() - DESIRED_MIX ) <= PRECISION 
          || !t2.is_empty()
          && fabs( t2.get_mix() - DESIRED_MIX ) <= PRECISION );
}

/**************************************************************************
 * Function: print_intro( )
 * Prints intro to puzzle
 *
 * Preconditions: Output is a beginning of line
 * Postconditions: Output is a beginning of line
 * Libraries: iostream
 **************************************************************************/
void print_intro( )
{
  cout << 
    "    Your object is to achieve in either tank a mixture such that the\n"
       <<
    "proportion of liquid A in the tank is equal to DESIRED_MIX.\n\n"
       <<
    "The prompt asks which tank you wish to work with and what you want to do with it.\n"
       <<
    "Valid responses are '1' or '2', or 'q' to quit the program.\n"
       <<
    "The second prompt asks what command to perform. Valid responses are:\n"
       <<
    "     'a' -- fill tank 1 up with liquid A\n"
       <<
    "     'b' -- fill tank 1 up with liquid B\n"
       <<
    "     'e' -- empty tank 1 \n"
       <<
    "     'p' -- pour the contents of tank 1 into the other tank\n"
       <<
    "     'A' -- fill tank 2 up with liquid A\n"
       <<
    "     'B' -- fill tank 2 up with liquid B\n"
       <<
    "     'E' -- empty tank 2 \n"
       <<
    "     'P' -- pour the contents of tank 2 into the other tank\n" 
       <<
    "When filling a tank, the liquid added to the tank will be mixed with\n"
       <<
    "anything that is already in the tank.\n"
       <<
    "When pouring a tank into the other tank, any liquid that does not fit in\n"
       <<
    "the receiving tank will remain behind.\n\n" 
       << 
    "The program continues until you either achieve the desired mix in either\n"
       <<
    "tank or give up and quit.\n"
       <<
    endl;
}

/**************************************************************************
 * Program: tankpuzzle
 * Declares two mixing tanks with capacities CAPACITY_1 and CAPACITY_2. Reads
 * in simple commands from standard input to fill one of the mixing tanks with
 * liquid A or liquid B, empty it, or pour it into the other mixing tank.
 * The user's object is to achieve in either tank a mixture such that the
 * proportion of liquid A in the tank is equal to DESIRED_MIX.
 *
 * The first prompt asks which tank the user wishes to work with for this
 * command. Valid responses are '1' or '2'. The user may also type 'q' to
 * quit the program.
 *
 * The second prompt asks what command to perform. Valid responses are:
 *      'a' -- fill the tank up with liquid A
 *	'b' -- fill the tank up with liquid B
 *	'e' -- empty the tank
 *	'p' -- pour the contents of the tank into the other tank
 *
 * When filling a tank, the liquid added to the tank will be mixed with
 * anything that is already in the tank.
 * When pouring a tank into the other tank, any liquid that does not fit in
 * the receiving tank will remain behind.
 *
 * Assumptions: CAPACITY_1 >= 0
 *              CAPACITY_2 >= 0
 *	       0.0 <= DESIRED_MIX <= 1.0
 *	       0 <= PRECISION <= 1
 *
 * Calls: fill_A, fill_B, empty, pour, print_status, check_victory
 * Libraries: iostream, cstdlib, cassert, CarnegieMellonGraphics.h
 **************************************************************************/

int main()
{
  const double CAPACITY_1 = 300.0; // Capacity of tank 1
  const double CAPACITY_2 = 500.0; // Capacity of tank 2
  const double DESIRED_MIX = 0.24; // Mix the user is to achieve
  const double PRECISION  = 0.0001; // Precision to use
  // when checking victory conditions.
  // Necessary because of rounding errors
  // in floating-point math that make simple
  // x == y statements impossible.

  mixing_tank t1( "Tank 1", CAPACITY_1, 0, 0 );
  mixing_tank t2( "Tank 2", CAPACITY_2, WIDTH/2, 0 );
  
  // WIDTH x HEIGHT at <INITX,INITY>, 16 bpp, 60 Hz. refresh
  Window window(INITX, INITY, WIDTH, HEIGHT, "Tank Puzzle",false,16,60);
  init_display( window );
  
  draw_target( window, helvet );

  print_intro( );

  /* Program loop
     Postcondition: User has entered 'q' at input loop 1
  */
  while( true )
    {
      displayTanks(t1, t2, window, helvet);

      if( check_victory( t1, t2, DESIRED_MIX, PRECISION ) )
	{
          const Transform bang( 45, 2, 10 );
          window.drawText( Style(Color::BLUE), roman, //275, 500
                           80, 
                           600, "VICTORY!!",
                           Transform(-5,5, 25) );
	  cout << "Victory conditions achieved." << endl;
        }

      window.reDraw();

      /* Input loop 1
	 Postcondition: option has been input to either '1', '2', or 'q'
      */
      /* char option, tank;   
         do
         {
         cout << "Which tank? [12q] ";
         cin >> option;
         } while( option != '1' && option != '2' && option != 'q' );
      
         tank = option;

         if( option == 'q' )
         exit(EXIT_SUCCESS);
      
         assert( option == '1' || option == '2' );
     
         Input loop 2
         Postcondition: option has been input to either 'a', 'b', 'e', or 'p'
         do
         {
         cout << "Action: [abep] ";
         cin >> option;
         } while( option != 'a' && option != 'b' && option != 'e'
         && option != 'p' );
      */
      /* Input parser
         Preconditions: option is 'a', 'b', 'e', or 'p', tank is '1' or '2'
         Postconditions: proper action according to input has been taken
      */
      
      TimerEvent timer = window.startTimer( ANIM_SPEED );

      while( !window.isKeyboardQueueEmpty() )
        {
          KeyboardEvent event = window.getKeyboardEvent(); 
          if ( event == KeyboardEvent('a') )  //Adhish: events for keyboard
            {
              t1.set_status(mixing_tank::FILLA);  //Adhish: sets status as a
                                                  //new status
            }
          
          else if ( event == KeyboardEvent('A'))
            {
              t2.set_status(mixing_tank::FILLA);
            }
          
          else if( event == KeyboardEvent ('b') )
            {
              t1.set_status(mixing_tank::FILLB);
            }
          
          else if( event == KeyboardEvent ('B') )
            {
              t2.set_status(mixing_tank::FILLB);
            }
              
          else if( event == KeyboardEvent ('e') )
            {
              t1.set_status(mixing_tank::EMPTY);
            }
          
          else if(event == KeyboardEvent ('E') )
            {
              t2.set_status(mixing_tank::EMPTY);
            }
          
          else if( event == KeyboardEvent ('p') )
            {
              t1.set_status(mixing_tank::POUR);
            }
          
          else if(event == KeyboardEvent ('P'))
            { 
              t2.set_status(mixing_tank::POUR);
            }              
          
          // else
          //   {
          //     t1.set_status(mixing_tank::STATIC);
          //     t2.set_status(mixing_tank::STATIC);
          //   }
        }

      if (t1.get_status() == mixing_tank::FILLA)  //Adhish: If the current
                                                  //status is a valid enum the
                                                  //do this..
        { 
          window.waitForTimerEvent();
          fill_A( t1 );
          displayTanks(t1, t2, window, helvet);
          window.reDraw();
        }
      
      
      if (t2.get_status() == mixing_tank::FILLA)
        { 
          window.waitForTimerEvent();
          fill_A( t2 );
          displayTanks(t1, t2, window, helvet);
          window.reDraw();
        }

      if (t1.get_status() == mixing_tank::FILLB)
        { 
          window.waitForTimerEvent();
          fill_B( t1 );
          displayTanks(t1, t2, window, helvet);
          window.reDraw();
        }

      if (t2.get_status() == mixing_tank::FILLB)
        { 
          window.waitForTimerEvent();
          fill_B( t2 );
          displayTanks(t1, t2, window, helvet);
          window.reDraw();
        }

      if (t1.get_status() == mixing_tank::EMPTY)
        { 
          window.waitForTimerEvent();
          empty( t1 );
          displayTanks(t1, t2, window, helvet);
          window.reDraw();
        }


      if (t2.get_status() == mixing_tank::EMPTY)
        { 
          window.waitForTimerEvent();
          empty( t2 );
          displayTanks(t1, t2, window, helvet);
          window.reDraw();
        }

      if (t1.get_status() == mixing_tank::POUR)
        { 
          window.waitForTimerEvent();
          pour( t1, t2 );
          displayTanks(t1, t2, window, helvet);
          window.reDraw();
        }

      if (t2.get_status() == mixing_tank::POUR)
        { 
          window.waitForTimerEvent();
          pour( t2, t1 );
          displayTanks(t1, t2, window, helvet);
          window.reDraw();
        }
    
      window.stopTimer(timer);
    }   
}   

