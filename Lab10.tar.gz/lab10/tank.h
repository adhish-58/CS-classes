/*****************************************************************************
 * FILE: tank.h    Lab 9 version (animated)                                  *
 * CLASS PROVIDED: mixing_tank (part of namespace CS256_CMGLab2)             *
 *  AUTHOR: J. Rogers                                                        *
 *  MODIFIED:  N. Sommer (April 2003) --- Added display() and position       *
 *  MODIFIED:  C. Kern (April 2004) --- Added animation                      *
 *                                                                           *
 * TYPES PROVIDED:                                                           *
 *    mixing_tank::Condition --- states of tanks                             *
 *                                                                           *
 * CONSTRUCTORS:                                                             *
 *   mixing_tank( )                                                          *
 *    Preconditions: none                                                    *
 *    Postconditions:  The tank has capacity 100 and is empty                *
 *                                                                           *
 *   mixing_tank( double capacity, int initx, int inity );                   *
 *    Preconditions: capacity is non-negative                                *
 *    Postconditions: The tank has the specified capacity and is empty       *
 *                    and is at position <initx, inity>                      *
 *                                                                           *
 * MODIFICATION MEMBER FUNCTIONS:                                            *
 *   void add_A( double quantity )                                           *
 *     Preconditions: quantity is non-negative                               *
 *                    quantity is no greater than remaining capacity         *
 *     Postconditions: quantity of liquid `A' has been added to tank         *
 *                                                                           *
 *   void add_B( double quantity )                                           *
 *     Preconditions: quantity is non-negative                               *
 *                    quantity is no greater than remaining capacity         *
 *     Postconditions: quantity of liquid `A' has been added to tank         *
 *                                                                           *
 *   double draw( double quantity );                                         *
 *     Preconditions: quantity is non-negative                               *
 *     Postconditions: if quantity is no greater than the current volume     *
 *                       then quantity of the mixed liquid has been removed  *
 *                       from the tank.  Otherwise the tank has been emptied *
 *                                                                           *
 * CONSTANT MEMBER FUNCTIONS:                                                *
 *   double get_volume( )                                                    *
 *     Preconditions: None                                                   *
 *     Postconditions: 0 <= return value <= capacity of tank                 *
 *                     Return value is volume of mixed liquid in tank        *
 *                                                                           *
 *   double get_space( )                                                     *
 *     Preconditions: None                                                   *
 *     Postconditions: 0 <= return value <= capacity of tank                 *
 *                     Return value is remaining capacity of tank            *
 *                                                                           *
 *   double get_mix( )                                                       *
 *     Preconditions: tank is not empty                                      *
 *     Postconditions: 0.0 <= return value <= 1.0                            *
 *                     Return value is proportion of A in tank               *
 *                                                                           *
 *   bool is_empty( )                                                        *
 *     Preconditions: None                                                   *
 *     Postconditions: Returns true iff tank is empty                        *
 *                                                                           *
 *   void display( Window &w );                                              *
 *     Preconditions: None                                                   *
 *     Postconditions: Tank is drawn at position <x, y> in Window w          *
 *                                                                           *
 * VALUE SEMANTICS                                                           *
 *  Assignments and copy constructor may be used with the mixing_tank class  *
 *  (via the automatic operators).                                           *
 *                                                                           *
 * LIBRARIES:  cassert for assert( )                                         *
 *             CarnegieMellonGraphics.h for graphics                         *
 *                                                                           *
 * NAMESPACE  CS256_CMGLab2                                                  *
 *                                                                           *
 *****************************************************************************/
#ifndef CS256_tank
#define CS256_tank

#include <string>
#include <CarnegieMellonGraphics.h>

namespace CS256_CMGLab2
{



  class mixing_tank
    {
    public:
      // CONSTRUCTORS
      mixing_tank( );
      mixing_tank( std::string initname, double capacity, 
                   int initx, int inity );
      enum status_type {FILLA, FILLB, EMPTY, POUR, STATIC};  //Adhish: set enum
                                                             //values for all
                                                             //the possible commands

      // MODIFICATION MEMBER FUNCTIONS
      void add_A( double quantity );
      void add_B( double quantity );
      double draw( double quantity );
      void set_status (status_type new_status);   //Adhish: This function sets
                                                  //a new status as my current status
      // CONSTANT MEMBER FUNCTIONS
      double get_space( ) const;
      double get_volume( ) const;
      double get_mix( ) const;
      bool is_empty( ) const;
      void display( Window& w ) const;
      status_type get_status( ) const;  //Adhish: This function gives me the
                                        //current status
    private:
      std::string name;                  // name of tank
      double max_capacity;           // total capacity of tank
      double vol_A;                  // current volume of A
      double vol_B;                  // current volume of B
      int x;                        // coordinates to place tank
      int y;
      status_type current_status;  //Adhish: declared variable for my current status 
    };

}

#endif
