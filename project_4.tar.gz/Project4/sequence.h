/*****************************************************************************
 * FILE: sequence.h (Project 4 version)                                      *
 * CLASS PROVIDED: sequence (a container class for a sequence of items,      *
 * where each sequence may have a designated item called the current item)   *
 *                                                                           *
 * Originally by:   Selena Billington selena@nagina.cs.colorado.edu          *
 * Modified by:  J. Rogers, Feb/2001                                         *
 *  Added get_capacity and a variety of documentation                        *
 *  Changed return type of assignment operator to sequence&                  *
 *                                                                           *
 * TYPEDEF and MEMBER CONSTANTS for the sequence class:                      *
 *   typedef ____ value_type                                                 *
 *     sequence::value_type is the data type of the items in the sequence.   *
 *     It may be any of the C++ built-in types (int, char, etc.), or a class *
 *     with a default constructor, an assignment operator, and a copy        *
 *     constructor.                                                          *
 *                                                                           *
 *   typedef ____ size_type                                                  *
 *     sequence::size_type is the data type of any variable that keeps track *
 *     of how many items are in the sequence.                                *
 *                                                                           *
 * CONSTRUCTORS AND DESTRUCTOR for the sequence class:                       *
 *   sequence( )                                                             *
 *     Postcondition: The sequence has been initialized as an empty sequence.*
 *                                                                           *
 *   sequence(const sequence& source)                                        *
 *     Copy constructor                                                      *
 *     Postcondition: The sequence contains a copy of source.                *
 *                                                                           *
 *   ~sequence( )                                                            *
 *     Destructor                                                            *
 *     Precondition: Class invariants are valid.  In particular, data points *
 *     to a dynamically allocated array in the heap.                         *
 *     Postcontition: All dynamically allocated memory for this instance has *
 *     been released.                                                        *
 *                                                                           *
 * MODIFICATION MEMBER FUNCTIONS for the sequence class:                     *
 *                                                                           *
 *   void start( )                                                           *
 *     Postcondition: The first item on the sequence becomes the current     *
 *     item (but if the sequence is empty, then there is no current item).   *
 *                                                                           *
 *   void advance( )                                                         *
 *     Precondition: is_item is true.                                        *
 *     Postcondition: If the current item was already the last item on the   *
 *     sequence, then there is no longer any current item. Otherwise, the new*
 *     current item is the item immediately after the original current item. *
 *                                                                           *
 *   void insert(const value_type& entry)                                    *
 *     Postcondition: A new copy of entry has been inserted in the sequence  *
 *     before the current item. If there was no current item, then the new   *
 *     entry has been inserted at the front of the sequence. In either case, *
 *     the newly inserted item is now the current item of the sequence.      *
 *                                                                           *
 *   void attach(const value_type& entry)                                    *
 *     Postcondition: A new copy of entry has been inserted in the sequence  *
 *     after the current item. If there was no current item, then the new    *
 *     entry has been attached to the end of the sequence. In either case,   *
 *     the newly inserted item is now the current item of the sequence.      *
 *                                                                           *
 *   void remove_current( )                                                  *
 *     Precondition: is_item returns true.                                   *
 *     Postcondition: The current item has been removed from the sequence,   *
 *     and the item after this (if there is one) is now the new current item.*
 *                                                                           *
 *    sequence& operator= ( const sequence& rhs )                            *
 *     Assignment operator                                                   *
 *     Postcondition: The sequence contains a copy of rhs.                   *
 *     Returns a reference to *this to allow assigments to be chained.       *
 *     (NOTE:  This allows code like:  s1 = s2 = s3;                      )  *
 *     (       To make this work you should end make your implementation  )  *
 *     (       return *this                                               )  *
 *                                                                           *
 * CONSTANT MEMBER FUNCTIONS for the sequence class:                         *
 *   size_type size( ) const                                                 *
 *     Postcondition: The return value is the number of items on the sequence*
 *                                                                           *
 *   bool is_item( ) const                                                   *
 *     Postcondition: A true return value indicates that there is a valid    *
 *     "current" item that may be retrieved by activating the current        *
 *     member function (sequenceed below). A false return value indicates    *
 *     that there is no valid current item.                                  *
 *                                                                           *
 *   value_type current( ) const                                             *
 *     Precondition: is_item( ) returns true.                                *
 *     Postcondition: The item returned is the current item on the sequence. *
 *                                                                           *
 * DEBUGGING FUNCTION:                                                       *
 *   This header includes the inline function bool verify_invariants()       *
 *    which may be called at the end of each member function, just prior     *
 *    to returning, to verify that the member variables are at least         *
 *    consistent:                                                            *
 *                                                                           *
 *    void sequence::memberFunction()                                        *
 *    {                                                                      *
 *      ...                                                                  *
 *      verify_invariants();                                                 *
 *      return;                                                              *
 *    }                                                                      *
 *                                                                           *
 * VALUE SEMANTICS for the sequence class:                                   *
 *   Assignments and the copy constructor may be used with sequence objects. *
 *                                                                           *
 * DYNAMIC MEMORY USAGE by the sequence class                                *
 *   If there is insufficient dynamic memory, then the following functions   *
 *   throw bad_alloc: The constructors, reserve, insert, attach and the      *
 *   assignment operator..                                                   *
 *                                                                           *
 * NAMESPACE: CS256_Project4                                                    *
 *                                                                           *
 * LIBRARIES USED: cstdlib --- for size_t                                    *
 *                 cassert --- for assert in verify_invariants()             *
 *                 node.h --- linked list toolkit                            *
 *                                                                           *
 * USAGE:                                                                    *
 *  #include "sequence.h"                                                    *
 *     sequence seq;                                                         *
 *                                                                           *
 *  link with sequence.o and node.o                                          *
 *                                                                           *
 ****************************************************************************/
#ifndef SEQUENCE_H
#define SEQUENCE_H
#include <cstdlib> 
#include <cassert> 
#include "node.h"

namespace CS256_Project4
{
  class sequence
  {
  public:
    // TYPEDEF and MEMBER CONSTANTS 
    typedef CS256_Node::node::value_type value_type;  // Type of items
    typedef std::size_t size_type;        // Type of size parameters

    // CONSTRUCTORS and DESTRUCTOR
    sequence();
    sequence(const sequence& source);
    ~sequence( );

    // MODIFICATION MEMBER FUNCTIONS
    void start( );
    void advance( );
    void insert(const value_type& entry);
    void attach(const value_type& entry);
    void remove_current( );
    sequence& operator =(const sequence& source);

    // CONSTANT MEMBER FUNCTIONS
    size_type size( ) const;
    bool is_item( ) const;
    value_type current( ) const;
    
    inline void verify_invariants() const;
    
  private:
    CS256_Node::node *head_ptr;  // Pointer to first node in list
    CS256_Node::node *tail_ptr;  // Pointer to last node in list
    CS256_Node::node *cursor;    // Internal iterator
    CS256_Node::node *precursor; // Pointer to node prior to cursor
    size_type many_nodes;        // Number of items in sequence
  };

/****************************************************************************
 * FUNCTION: inline bool verify_invariants()                                *
 *  Aborts with an assert failure if the values of head_ptr, tail_ptr,      * 
 *   cursor, precursor and many_nodes  are not consistent with the class    *
 *   invariants.                                                            *
 ****************************************************************************/
  inline void sequence::verify_invariants() const
    {
      bool aNull = (head_ptr == NULL || tail_ptr == NULL || many_nodes == 0);
      bool allNull = (head_ptr == NULL && tail_ptr == NULL && many_nodes == 0
                      && cursor == NULL && precursor == NULL);
      bool empty_ptrs_OK = ( (aNull && allNull) || !aNull);
      bool cursor_follows_precursor = 
        ( (precursor != NULL && precursor->link() == cursor) 
         || precursor == NULL);
      bool precursor_preceeds_cursor = 
        ( (cursor == head_ptr && precursor == NULL) || cursor != head_ptr);
         
      assert(empty_ptrs_OK);
      // Fails if head_ptr or tail_ptr is NULL or many_nodes is 0, indicating 
      //  that the list should be empty, but one of the other pointers is not
      //  NULL or many_nodes is not 0, indicating that it is not empty

      assert(cursor_follows_precursor);
      // Fails if the precursor is not NULL but the cursor is not the same as
      //   precursor->link()

      assert(precursor_preceeds_cursor);
      // Fails if if the cursor is at the head but the precursor is not NULL
    }
}  
#endif
  
