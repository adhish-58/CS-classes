/****************************************************************************
 * FILE: sequence_adaptor.cpp                                               *
 * Implementation of adaptor functions for the sequence class.              *
 *  JRogers, Mar/2003                                                       *
 ****************************************************************************/
#include "sequence_adaptor.h"

namespace CS256_Project4
{
  Wsequence::Wsequence()
  {
    seqP = new sequence();
  }
  
  Wsequence::Wsequence(const Wsequence& source)
  {
    seqP= new sequence(*source.seqP);
  }
  
  Wsequence::~Wsequence( )
  {
    delete seqP;
  }
  
  // MODIFICATION MEMBER FUNCTIONS
  void Wsequence::start( ){ seqP->start(); }
  void Wsequence::advance( ){ seqP->advance( ); }
  void Wsequence::insert(const value_type& entry){ seqP->insert(entry); }
  void Wsequence::attach(const value_type& entry){ seqP->attach(entry); }
  void Wsequence::remove_current( ){ seqP->remove_current( ); }
  const Wsequence& Wsequence::operator =(const Wsequence& source)
  {
    *seqP = *source.seqP;
    return *this;
  }
  
  // CONSTANT MEMBER FUNCTIONS
  sequence::size_type Wsequence::size( ) const{ return seqP->size(); }
  bool Wsequence::is_item( ) const{ return seqP->is_item(); }
  sequence::value_type Wsequence::current( ) const{ return seqP->current(); }
  
}


//end of sequence_adaptor.cpp

