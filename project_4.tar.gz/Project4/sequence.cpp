//Adhish Adhikari, Independent programming project 4, Friday,May1,2015

/* Invariants:

   head_ptr - Pointer to first node in list. If the lsit is empty, head_ptr == NULL
   tail_ptr - Pointer to last node in list. If the list is empty, tail_ptr == NULL
   cursor - Internal iterator. IF there is no current item then cursor == NULL.
   precursor -  Pointer to node prior to cursor. If the current item is in the
   first node of the lsit, the cursor = head_ptr and precursor = NULL.
   many_nodes -  Number of items in sequence. If the lsit is empty, many_nodes
   == 0
IF precursor != NULL, then precursor -> link() == cursor. In the case precursor
   is pointing to the tail_ptr, cursor is NULL. We might or might or might not
   declare precursor == NULL when cursor == NULL.
 It is permissible but not required.
If the list is empty then all four pointers are required to be NULL and
   many_items must be 0.
If the list is not empty then neither head_ptr or tail_ptr are NULL and
   many_nodes is greater than zero.
 */

#include <cstdlib> 
#include <cassert>
#include "sequence.h" 
#include "node.h"

using namespace std;
using namespace CS256_Node;

namespace CS256_Project4
{
 /****************************************************************************
    CONSTRUCTORS AND DESTRUCTORS
    sequence()
    Postcondition: The sequence has been initialized as an empty sequence
  ****************************************************************************/
  sequence::sequence() 
  {
    head_ptr = '\0';
    tail_ptr = '\0';
    cursor = '\0';
    precursor = '\0';
    many_nodes = 0;
  }

 /***************************************************************************
  *  sequence( const sequence& source)
  *   Copy constructor
  *   Postconditions: The sequence contains a copy of source.
  *****************************************************************************/

  sequence::sequence(const sequence& source)
  {
    head_ptr = '\0';
    many_nodes = 0;
    *this =source;
    return;
  }

/***************************************************************************
      ~sequence( )                                                            *
 *     Destructor                                                            *
 *     Precondition: Class invariants are valid.  In particular, data points *
 *     to a dynamically allocated array in the heap.                         *
 *     Postcontition: All dynamically allocated memory for this instance has *
 *     been released. 
  *****************************************************************************/

  sequence::~sequence()
  {
    head_ptr = '\0';
    tail_ptr = '\0';
    cursor = '\0';
    precursor = '\0';
    many_nodes = 0;
    list_clear(head_ptr);
  }

/***************************************************************************
     void start( )                                                           *
 *     Postcondition: The first item on the sequence becomes the current     *
 *     item (but if the sequence is empty, then there is no current item).   *
 *                                                                           *
 *****************************************************************************/

  void sequence::start() 
  {
    cursor = head_ptr;
    precursor = '\0'; 
  } 
 
/***************************************************************************
 void advance( )                                                         *
 *     Precondition: is_item is true.                                        *
 *     Postcondition: If the current item was already the last item on the   *
 *     sequence, then there is no longer any current item. Otherwise, the new*
 *     current item is the item immediately after the original current item. *
 *****************************************************************************/

  void sequence::advance()
  {
    assert(is_item());

    if(precursor == '\0')
      {
        precursor = head_ptr;
      }

    else
      {
        precursor = precursor->link();
        precursor = cursor;
      }

    cursor = cursor->link();
  }

/***************************************************************************
 void insert(const value_type& entry)                                    *
 *     Postcondition: A new copy of entry has been inserted in the sequence  *
 *     before the current item. If there was no current item, then the new   *
 *     entry has been inserted at the front of the sequence. In either case, *
 *     the newly inserted item is now the current item of the sequence.      *
 *****************************************************************************/

  void sequence::insert(const value_type& entry)
  {
    if((many_nodes == 0) || ((many_nodes > 0) && (is_item() == false)) || (cursor == head_ptr))
      {
        list_head_insert(head_ptr, entry);
        cursor = head_ptr;
        precursor = '\0';
      }

    else
      {
        list_insert(precursor, entry);
        cursor = precursor->link();
      }

    many_nodes++;
  }

/***************************************************************************
 void attach(const value_type& entry)                                    *
 *     Postcondition: A new copy of entry has been inserted in the sequence  *
 *     after the current item. If there was no current item, then the new    *
 *     entry has been attached to the end of the sequence. In either case,   *
 *     the newly inserted item is now the current item of the sequence.     
 *****************************************************************************/

  void sequence::attach(const value_type& entry)
  {
    if(many_nodes == 0)
      {
        list_head_insert(head_ptr, entry);
        start();
      }

    else if(many_nodes > 0 && (is_item() == false))
      {
        list_insert(precursor, entry);
        cursor = precursor->link();
      }

    else
      {
        list_insert(cursor, entry);
        advance();
      }

    many_nodes++;
  }

/***************************************************************************
  void remove_current( )                                                  *
 *     Precondition: is_item returns true.                                   *
 *     Postcondition: The current item has been removed from the sequence,   *
 *     and the item after this (if there is one) is now the new current item.*
 *****************************************************************************/

  void sequence::remove_current()
  {
    assert(is_item() == true);

    if(cursor == head_ptr)
      {
        list_head_remove(cursor);
        head_ptr = cursor;
      }

    else
      {
        list_remove(precursor);
        cursor = precursor->link();
      }

    many_nodes--;
  } 

/***************************************************************************
 sequence& operator= ( const sequence& rhs )                            *
 *     Assignment operator                                                   *
 *     Postcondition: The sequence contains a copy of rhs.                   *
 *     Returns a reference to *this to allow assigments to be chained.       *
 *     (NOTE:  This allows code like:  s1 = s2 = s3;                      )  *
 *     (       To make this work you should end make your implementation  )  *
 *     (       return *this                    
 *****************************************************************************/

  sequence& sequence::operator =(const sequence& source)
  {
    if (this != &source)
      {
        list_clear(head_ptr);

        many_nodes = source.size();
        list_copy(source.head_ptr,head_ptr, tail_ptr);

        many_nodes = source.many_nodes;
        precursor = source.precursor;
        cursor = source.cursor;

        if (source.is_item())
          {
            if (source.precursor == '\0')
              {
                start();
              }
          }
      }

    return *this;
  }

/***************************************************************************
 size_type size( ) const                                                 *
 *     Postcondition: The return value is the number of items on the sequence*
 *****************************************************************************/

  sequence::size_type sequence::size() const 
  { 
    return many_nodes; 
  } 
  
/***************************************************************************
 bool is_item( ) const                                                   *
 *     Postcondition: A true return value indicates that there is a valid    *
 *     "current" item that may be retrieved by activating the current        *
 *     member function (sequenceed below). A false return value indicates    *
 *     that there is no valid current item.    
 *****************************************************************************/

  bool sequence::is_item() const 
  { 
    if(cursor != '\0') 
      { 
        return true; 
      } 
    
    else
      {
        return false;
      } 
  }

/***************************************************************************
 value_type current( ) const                                             *
 *     Precondition: is_item( ) returns true.                                *
 *     Postcondition: The item returned is the current item on the seque
 *****************************************************************************/
  
  sequence::value_type sequence::current() const
  {
    assert(is_item());
    return (cursor->data());
  }
}
