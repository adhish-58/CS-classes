/****************************************************************************
 *  FILE: sequence_test.cpp  --- Linked list version (Project 4)            *
 *  An interactive test program for the new sequence class                  *
 *                                                                          *
 *  Written by: Ian Kelly March/2001                                        *
 *  Modified: J. Rogers March/2002                                          *
 *             Cleaned up get_seq_ptr( )                                    *
 *             Added non-interactive mode, precondition warnings, displays  *
 *             and J. Howell's comment mechanism                            *
 *            J. Rogers March/2002                                          *
 *             Adapted from asgn4 version                                   *
 *                                                                          *
 *   This version of sequence_test uses two sequences (1 and 2) to allow    *
 *    testing of assignment operator and copy constructor.  Scripts for     *
 *    the Asgn 3 version will need to be modified to select the sequence    *
 *    by adding either 1 or 2 after each command (and before the value, if  *
 *    any).  So "+" becomes "+ 1" or "+ 2" and "i 17" becomes "i 1 17" or   *
 *    "i 2 17".                                                             *
 *                                                                          *
 *   Commands:                                                              *
 *      !   Activate the start( ) function                                  *
 *      +   Activate the advance( ) function                                *
 *      ?   Print the result from the is_item( ) function                   *
 *      =   Assign one sequence to the other                                *
 *      @   Copy one sequence to the other using the copy constructor       *
 *      D   Display all information about the sequence                      *
 *      C   Print the result from the current( ) function                   *
 *      P   Print a copy of the entire sequence                             *
 *      S   Print the result from the size( ) function                      *
 *      I   Insert a new number with the insert(...) function               *
 *      A   Attach a new number with the attach(...) function               *
 *      R   Activate the remove_current( ) function                         *
 *      N   Reallocate sequence (empty)
 *      M   Print this menu                                                 *
 *      F   Toggle interactive mode (normally on)                           *
 *      Q   Quit this test program                                          *
 *                                                                          *
 *                                                                          *
 ****************************************************************************/

#include <cctype>       // Provides toupper
#include <iostream>     // Provides cout and cin
#include <cstdlib>      // Provides EXIT_SUCCESS
#include "sequence.h"   // With value_type defined as double
using namespace std;
using namespace CS256_Node;
using namespace CS256_Project4;

// PROTOTYPES for functions used by this test program:

void print_menu( ); //

char get_user_command( bool echo ); //

void print_current(const sequence& s ); // Print current or "No current item"

void show_sequence(sequence& display); // show contents

void display_sequence(sequence& s); // display all info

sequence::value_type get_value( bool echo ); // Prompt for and read a value

sequence::size_type get_size( bool echo ); // Prompt for and read capacity

sequence*& get_seq_ptr( sequence*& sp1, sequence*& sp2, bool echo);
// Prompts for sequence number and returns reference to corresponding pointer

void assign_sequence( sequence* s1, sequence* s2, bool echo );

void copy_sequence( sequence*& s1, sequence*& s2, bool echo );

void reallocate_sequence( sequence*& s1, sequence*& s2, bool echo );

bool warn_user( bool condition, const char message[] ); 
//  if condition evaluates to true get user's premission to proceed
//  returns true if condition is false or user says `y'


int main( )
{
  sequence *test1 = new sequence; // A sequence that we'll perform tests on
  sequence *test2 = new sequence; // A second sequence to test with
  sequence *temp_p;               // temp pointer

  char choice;                    // A command character entered by the user
  bool interactive = true;        // True iff in interactive mode
  
  cout << "I have initialized two empty sequences" << endl;
  print_menu( );
  
  do
    {
      choice = toupper(get_user_command( !interactive ));
      switch (choice)
        {
        case '!':  // start
          temp_p = get_seq_ptr(test1, test2, !interactive);
          temp_p->start( );
          print_current( *temp_p );
          break;
        case '+':  // advance
	  temp_p = get_seq_ptr(test1, test2, !interactive);
          if ( warn_user( !(temp_p->is_item( )),
                          "Advance with no current item " )
               )
            {
              temp_p->advance( );
              print_current( *temp_p );
            }
          break;
        case '?':  // is_item()
          if (get_seq_ptr(test1, test2, !interactive)->is_item( ))
            cout << "There is an item." << endl;
          else 
            cout << "There is no current item." << endl;
          break;
	case '=':  // assignment operator
	  assign_sequence(test1, test2, !interactive);
	  break;
	case '@':  // copy constructor
	  copy_sequence(test1, test2, !interactive);
	  break;
        case 'C':  // current
	  print_current( *get_seq_ptr(test1, test2, !interactive) );
          break;
        case 'P':  // print sequence
          show_sequence(*get_seq_ptr(test1, test2, !interactive));
          break;
        case 'D':  // display sequence
          display_sequence(*get_seq_ptr(test1, test2, !interactive));
          break;
        case 'S':  // size()
          cout << "Size is " 
               << get_seq_ptr(test1, test2, !interactive)->size( ) 
               << '.' << endl;
          break;
        case 'I':  // insert
          temp_p = get_seq_ptr(test1, test2, !interactive );
          temp_p->insert(get_value(!interactive ));
          display_sequence( *temp_p );
          break;
        case 'A':  // attach
          temp_p = get_seq_ptr(test1, test2, !interactive );
          temp_p->attach(get_value(!interactive ));
          display_sequence( *temp_p );
          break;
        case 'R':  // remove_current
	  temp_p = get_seq_ptr(test1, test2, !interactive);
          if ( warn_user( !(temp_p->is_item( ) ),
                          "Remove current with no current item ")
               )
            {
              temp_p->remove_current( );
              display_sequence( *temp_p );
            }
          break;
        case 'N':  // reallocate
	  reallocate_sequence(test1, test2, !interactive);
          break;     
        case 'M':   
          print_menu( );
          break;
        case 'F':
          interactive = !interactive;
          if ( interactive ) 
            cout << "Interactive mode is on" << endl;
          else 
            cout << "f, Interactive mode is off" << endl;
          break;
        case '#':  // comment
          break;
        case 'Q':
          break;
        default:  cout << choice << " is invalid." << endl;
        }
      if ( !interactive && cin )
        {
          char nxtchar = cin.get();
          if ( nxtchar != '\n' )
            {
              do 
                {
                  cout<<nxtchar;
                  nxtchar = cin.get(); 
                } while (cin && nxtchar != '\n') ;
              cout << endl;
            }
        }
    }
  while (cin && (choice != 'Q'));
  
  delete test1;
  delete test2;

  return EXIT_SUCCESS;
}

/****************************************************************************
 * FUNCTION: void print_menu( )                                             *
 *  Postcondition: A menu of choices for this program has been written to   *
 *  cout.                                                                   *
 *  Library facilities used: iostream.h                                     *
 *                                                                          *
 ****************************************************************************/
void print_menu( )
{
    cout << endl;
    cout << "The following choices are available: " << endl;
    cout << " !   Activate the start( ) function" << endl;
    cout << " +   Activate the advance( ) function" << endl;
    cout << " ?   Print the result from the is_item( ) function" << endl;
    cout << " =   Assign one sequence to the other" << endl;
    cout << " @   Copy one sequence to the other using the copy constructor" 
         << endl;
    cout << " D   Display all information about the sequence" << endl;
    cout << " C   Print the result from the current( ) function" << endl;
    cout << " P   Print a copy of the entire sequence" << endl;
    cout << " S   Print the result from the size( ) function" << endl;
    cout << " I   Insert a new number with the insert(...) function" << endl;
    cout << " A   Attach a new number with the attach(...) function" << endl;
    cout << " R   Activate the remove_current( ) function" << endl;
    cout << " N   Construct a new sequence (empty)" << endl;
    cout << " M   Print this menu" << endl;
    cout << " F   Toggle interactive mode (normally on)\n";
    cout << " Q   Quit this test program" << endl;
}

/****************************************************************************
 * FUNCTION: char get_user_command( bool echo )                             *
 *  Library facilities used: iostream                                       *
 *  Postcondition: The user has been prompted to enter a one character      *
 *    command.  The next character has been read (skipping blanks and       *
 *    newline characters), and this character has been returned.            *
 *                                                                          *
 ****************************************************************************/
char get_user_command( bool echo )
{
    char command;

    cout << "Enter choice: ";
    cin >> command; 
    
    if ( echo ) cout << command << endl;

    return command;
}

/****************************************************************************
 * FUNCTION: void print_current( const sequence& s )                        *
 *   Postcondition: Current item has been printed, if any,                  *
 *     else prints "There is no current item."                              *
 *                                                                          *
 ****************************************************************************/
void print_current( const sequence& s )
{
  if (s.is_item( ))
    cout << "Current item is: " << s.current( ) << endl;
  else
    cout << "There is no current item." << endl;
  return;
}

/****************************************************************************
 * FUNCTION: void show_sequence(sequence display)                           *
 *  Library facilities used: iostream                                       *
 *  Postcondition: The items on display have been printed to cout           *
 *    (one per line).                                                       *
 *                                                                          *
 ****************************************************************************/
void show_sequence(sequence& display)
{
  sequence::size_type position;  // original position of current_item
  for (position = display.size();
       display.is_item();
       display.advance() )
    {
      // Invariant: 
      //   The position of the original current item is 
      //   position minus the number of items from current item to end of seq
      --position;
    }
  // Postcondition: There are no items from current item to end of seq
  //                position is the position of the original current item
 
  cout << "[";
  display.start( );
  if ( display.is_item() )
    {
      cout << display.current();
      for (display.advance( ); display.is_item( ); display.advance( ))
        cout << ", " << display.current( );
    }
  cout << "]" << endl;

  for ( display.start(); position != 0; --position )
    {
      // Invariant: 
      //   Original current item is at position of current item plus position
      display.advance();
    }
  // Postcondition: position == 0
  //                position of original current item is pos. of current item
}

/****************************************************************************
 * FUNCTION: void display_sequence(sequence& s)                             *
 *    Postcondtion: The capacity, size, current item and contents have      *
 *      been printed to cout.                                               *
 *                                                                          *
 ****************************************************************************/
void display_sequence(sequence& s)
{
  if ( s.size() == 0 )
    {
      cout << "Sequence is empty." << endl;
    }
  else
    {
      cout << "Size: " << s.size();
      if ( !s.is_item() )
        cout << ", No current item";
      else
        cout << ", Current: " << s.current();
      cout << "\n";
      show_sequence( s );
    }
}


/****************************************************************************
 * FUNCTION:  double get_value( bool echo )                                 *
 *  Library facilities used: iostream                                       *
 *  Postcondition: The user has been prompted to enter a real number. The   *
 *  number has been read, echoed to the screen, and returned by the         *
 *   function.                                                              *
 *                                                                          *
 ****************************************************************************/
double get_value( bool echo )
{
    double result;
    
    cout << "Please enter a value for the sequence: ";
    cin  >> result;
    if (echo )
      cout << result << endl;
    return result;
}

/****************************************************************************
 * FUNCTION:  sequence::size_type get_size( bool echo )                     *
 *  Library facilities used: iostream                                       *
 *  Postcondition: The user has been prompted to enter a size_type. The     *
 *  size_type has been read, echoed to the screen, and returned by the      *
 *    function.                                                             *
 *                                                                          *
 ****************************************************************************/
sequence::size_type get_size( bool echo )
{
	sequence::size_type size;
	
	cout << "Please enter a capacity for the sequence: ";
	cin >> size;
	if (echo) 
          cout << size << endl;;
	return size;
}

/****************************************************************************
 * FUNCTION:                                                                *
 *   sequence*& get_seq_ptr( sequence*& sp1, sequence*& sp2, bool echo)     *
 *  Library facilities used: iostream                                       *
 *  Precondition: s1 and s2 point to valid sequences.                       *
 *  Postcondition: The user has been prompted to choose a sequence.         *
 *    A (reference to a) pointer to either s1 or s2 has been returned.      *
 *                                                                          *
 ****************************************************************************/
sequence*& get_seq_ptr( sequence*& sp1, sequence*& sp2, bool echo)
{
  char input = '\0';

  while( cin && input != '1' && input != '2' )
    {
      cout << "which sequence (1 or 2)? ";
      cin >> input;
      
      if ( echo ) cout << input << endl;
    }

  if( input == '1' )
    return sp1;
  else // input == '2'
    return sp2;
}

/****************************************************************************
 * FUNCTION: void assign_sequence( sequence* s1, sequence* s2, bool echo )  *
 *  Precondition: s1 and s2 point to valid sequences.                       *
 *  Postcondition: The user has selected two sequences, and one has been    *
 *  assigned to the other via the assignment operator.                      *
 *                                                                          *
 ****************************************************************************/
void assign_sequence( sequence* s1, sequence* s2, bool echo )
{
  sequence *temp_p, *temp_p2;

  cout << "Assign to ";
  temp_p2 = get_seq_ptr(s1, s2, echo );
  cout << "Assign from ";
  temp_p = get_seq_ptr(s1, s2, echo );
  *temp_p2 = *temp_p;
}

/****************************************************************************
 * FUNCTION: void copy_sequence( sequence*& s1, sequence*& s2, bool echo )  *
 *  Precondition: s1 and s2 point to valid sequences.                       *
 *  Postcondition: The user has selected a sequence and that sequence has   *
 *  been reallocated via the copy constructor with the other sequence as    *
 *  the argument.                                                           *
 *                                                                          *
 ****************************************************************************/
void copy_sequence( sequence*& s1, sequence*& s2, bool echo )
{
  sequence* from_p;
  sequence* temp_p; // temporary pointer for reallocating before deleting

  cout << "Copy (from other sequence) to ";
  sequence*& to_p = get_seq_ptr(s1, s2, echo );
  if( to_p == s1 )
    from_p = s2;
  else // to_p == s2
    from_p = s1;
  temp_p = new sequence(*from_p);
  delete to_p;
  to_p = temp_p;
}

/****************************************************************************
 *  FUNCTION:                                                               *
 *   void reallocate_sequence( sequence*& s1, sequence*& s2, bool echo )    *
 *  Precondition: s1 and s2 point to valid sequences.                       *
 *  Postcondition: The user has selected a sequence and input a new size,   *
 *  and the sequence has been reallocated with that size.                   *
 *                                                                          *
 ****************************************************************************/
void reallocate_sequence( sequence*& s1, sequence*& s2, bool echo )
{
  sequence *temp_p;  // temporary pointer for reallocating before deleting

  cout << "Reallocate ";
  sequence*& from_p = get_seq_ptr(s1, s2, echo );
  temp_p = new sequence();
  delete from_p;
  from_p = temp_p;
}

/****************************************************************************
 * FUNCTION: bool warn_user( bool condition, char message[] )               *
 * Postconditions:                                                          *
 *   If condition evaluates false, function returns true                    *
 *   If condition evaluates true                                            *
 *     Prints "Warning:  " followed by message followed by                  *
 *            "---will violoate precondition.  Continue? [y,n]"             *
 *     Obtains 'y' or 'n' from cin                                          *
 *       Prompts and retries input until either 'y' or 'n' is entered       *
 *     returns true iff input is 'y' and cin has not failed                 *
 * Library facilities used: iostream                                        *
 ****************************************************************************/
bool warn_user( bool condition, const char message[] ) 
{
  char response;  // users response to warning

  if (condition)
    {
      cout << "Warning: " << message 
           << "---will violate precondition.\n Continue? [y,n] ";
      cin >> response;
      while ( response != 'y' && response != 'n' && cin )
        { 
          cout << "Please enter y or n:  ";
          cin >> response;
        }
      return (response == 'y' && cin );
    }
  return true;
}
