/****************************************************************************
 *  FILE: node.cpp                                                          *
 *  IMPLEMENTS: The functions of the node class and the                     *
 *              linked list toolkit (see node.h for documentation).         *
 *  WRITTEN: Main & Savitch                                                 *
 *  MODIFIED: Jim Rogers, Spring 2002                                       *
 *            Modified documentation                                        *
 *                                                                          *
 *  INVARIANTS for the node class:                                          *
 *    The data of a node is stored in data_field,                           *
 *      and the link in link_field                                          *
 *                                                                          *
 *  LIBRARIES: cassert, cstdlib                                             *
 ****************************************************************************/
#include "node.h"
#include <cassert>    // Provides assert
#include <cstdlib>    // Provides NULL and size_t
using namespace std;

namespace CS256_Node
{
/****************************************************************************
 * FUNCTION:                                                                *
 *    size_t list_length(const node* head_ptr)                              *
 *      Precondition: head_ptr is the head pointer of a linked list.        *
 *      Postcondition: The value returned is the number of nodes in the     *
 *      linked list.                                                        *
 ****************************************************************************/
  size_t list_length(const node* head_ptr)
  {
    const node *cursor;
    size_t answer;
    
    answer = 0;
    for (cursor = head_ptr; cursor != NULL; cursor = cursor->link( ))
      ++answer;
    
    return answer;
  }
  
/****************************************************************************
 * FUNCTION:                                                                *
 *    void list_head_insert(node*& head_ptr, const node::value_type& entry) *
 *      Precondition: head_ptr is the head pointer of a linked list.        *
 *      Postcondition: A new node containing the given entry has been added *
 *      at the head of the linked list; head_ptr now points to the head of  *
 *      the new, longer linked list.                                        *
 ****************************************************************************/
  void list_head_insert(node*& head_ptr, const node::value_type& entry)
  {
    head_ptr = new node(entry, head_ptr);
  }
  
/****************************************************************************
 * FUNCTION:                                                                *
 *    void list_insert(node* previous_ptr, const node::value_type& entry)   *
 *      Precondition: previous_ptr points to a node in a linked list.       *
 *      Postcondition: A new node containing the given entry has been added *
 *      after the node that previous_ptr points to.                         *
 ****************************************************************************/
  void list_insert(node* previous_ptr, const node::value_type& entry) 
  {
    node *insert_ptr;
    
    insert_ptr = new node(entry, previous_ptr->link( ));
    previous_ptr->set_link(insert_ptr);
  }
  
/****************************************************************************
 * FUNCTION:                                                                *
 *    node* list_search(node* head_ptr, const node::value_type& target)     *
 *      Precondition: head_ptr is the head pointer of a linked list.        *
 *      Postcondition: The pointer returned points to the first node        *
 *      containing the specified target in its data member. If there is no  *
 *      such node, the null pointer is returned.                            *
 ****************************************************************************/
  node* list_search(node* head_ptr, const node::value_type& target) 
  {
    node *cursor;
    
    for (cursor = head_ptr; cursor != NULL; cursor = cursor->link( ))
      if (target == cursor->data( ))
        return cursor;
    return NULL;
  }
  
  const node* list_search(const node* head_ptr, 
                          const node::value_type& target) 
  {
    const node *cursor;
    
    for (cursor = head_ptr; cursor != NULL; cursor = cursor->link( ))
      if (target == cursor->data( ))
        return cursor;
    return NULL;
  }

/****************************************************************************
 * FUNCTION:                                                                *
 *    node* list_locate(node* head_ptr, size_t position)                    *
 *      Precondition: head_ptr is the head pointer of a linked list, and    *
 *      position > 0.                                                       *
 *      Postcondition: The pointer returned points to the node at the       *
 *      specified position in the list. (The head node is position 1, the   *
 *      next node is position 2, and so on). If there is no such position,  *
 *      then the null pointer is returned.                                  *
 ****************************************************************************/
  node* list_locate(node* head_ptr, size_t position)  
  {
    node *cursor;
    size_t i;
    
    assert (0 < position);
    cursor = head_ptr;
    for (i = 1; (i < position) && (cursor != NULL); i++)
      cursor = cursor->link( );
    return cursor;
  }
  
  const node* list_locate(const node* head_ptr, size_t position) 
  {
    const node *cursor;
    size_t i;
    
    assert (0 < position);
    cursor = head_ptr;
    for (i = 1; (i < position) && (cursor != NULL); i++)
      cursor = cursor->link( );
    return cursor;
  }

/****************************************************************************
 * FUNCTION:                                                                *
 *    void list_head_remove(node*& head_ptr)                                *
 *      Precondition: head_ptr is the head pointer of a linked list, with   *
 *      at least one node.                                                  *
 *      Postcondition: The head node has been removed and returned to the   *
 *      heap; head_ptr is now the head pointer of the new, shorter linked   *
 *      list.                                                               *
 ****************************************************************************/
  void list_head_remove(node*& head_ptr)
  {
    node *remove_ptr;
    
    remove_ptr = head_ptr;
    head_ptr = head_ptr->link( );
    delete remove_ptr;
  }
  
/****************************************************************************
 * FUNCTION:                                                                *
 *    void list_remove(node* previous_ptr)                                  *
 *      Precondition: previous_ptr points to a node in a linked list, and   *
 *      this is not the tail node of the list.                              *
 *      Postcondition: The node after previous_ptr has been removed from    *
 *      the linked list.                                                    *
 ****************************************************************************/
  void list_remove(node* previous_ptr)
  {
    node *remove_ptr;
    
    remove_ptr = previous_ptr->link( );
    previous_ptr->set_link( remove_ptr->link( ) );
    delete remove_ptr;
  }
  
/****************************************************************************
 * FUNCTION:                                                                *
 *    void list_clear(node*& head_ptr)                                      *
 *      Precondition: head_ptr is the head pointer of a linked list.        *
 *      Postcondition: All nodes of the list have been returned to the heap,*
 *      and the head_ptr is now NULL.                                       *
 ****************************************************************************/
  void list_clear(node*& head_ptr)
  {
    while (head_ptr != NULL)
      list_head_remove(head_ptr);
  }
  
/****************************************************************************
 * FUNCTION:                                                                *
 *    void list_copy(const node* source_ptr,                                *
 *                   node*& head_ptr, node*& tail_ptr)                      *
 *      Precondition: source_ptr is the head pointer of a linked list.      *
 *      Postcondition: head_ptr and tail_ptr are the head and tail pointers *
 *      for a new list that contains the same items as the list pointed to  *
 *      by source_ptr. The original list is unaltered.                      *
 ****************************************************************************/
  void list_copy(const node* source_ptr, node*& head_ptr, node*& tail_ptr) 
  {
    head_ptr = NULL;
    tail_ptr = NULL;
    
    if (source_ptr == NULL)   // List is empty
      return;
    
    list_head_insert(head_ptr, source_ptr->data( ));
    tail_ptr = head_ptr;
    
    source_ptr = source_ptr->link( ); 
    while (source_ptr != NULL)
      {
        list_insert(tail_ptr, source_ptr->data( ));
        tail_ptr = tail_ptr->link( );
        source_ptr = source_ptr->link( );
      }
  }
}
