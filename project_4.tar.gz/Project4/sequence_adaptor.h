/****************************************************************************
 * FILE: sequence_adaptor.h     Project 4 version                           *
 *  Adaptor functions for the sequence class.                               *
 *  JRogers, Mar/2003                                                       *
 ****************************************************************************/
#ifndef SEQUENCE_A
#define SEQUENCE_A

#include "sequence.h"

namespace CS256_Project4
{
  class Wsequence
  {
  public:
    // TYPEDEF and MEMBER CONSTANTS 
    typedef CS256_Node::node::value_type value_type;  // Type of items
    typedef std::size_t size_type;        // Type of size parameters

    // CONSTRUCTORS and DESTRUCTOR
    Wsequence();
    Wsequence(const Wsequence& source);
    ~Wsequence( );

    // MODIFICATION MEMBER FUNCTIONS
    void start( );
    void advance( );
    void insert(const sequence::value_type& entry);
    void attach(const sequence::value_type& entry);
    void remove_current( );
    const Wsequence& operator =(const Wsequence& source);

    // CONSTANT MEMBER FUNCTIONS
    sequence::size_type size( ) const;
    bool is_item( ) const;
    sequence::value_type current( ) const;

  private:
    sequence* seqP;        // Wrapped sequence
  };
}

#endif // ifndef SEQUENCE_A
