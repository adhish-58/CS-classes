#include <iostream> 
#include <cstdlib> // for dynamic memory allocation
#include <fstream> //for output and input files that stores random numbers and sorted numbers
#include <time.h> //for clock variable and some other time calculating functions
#include <limits> //for the infinity value
#include <math.h> //for general math functions ex. floor etc

using namespace std;

void random_number_generator(int size) //function generates random number and pushes it onto a text file
{
  ofstream myfile; //declare text file as ofstream
  myfile.open("random_number_list.txt"); //open text file
  for(int i=0; i<size; ++i)
  {
    myfile<<rand()%size<<" ";
  }
  myfile.close(); //close text file
}

void makearray(int A[], int size) //function to convert the text file into an array
{
  ifstream myfile("random_number_list.txt"); //open the text file
  if(myfile.is_open())
    {
      for(int i=0; i<size; ++i)
        {
          myfile >> A[i]; //store the elements of the etxt file into an array
        }
    }
  myfile.close(); //close text file
}

void insertion(int A[], int size) //function to sort the random numbers with insertion sort
{
  for(int j=1; j<=size; ++j) 
  {
    int key = A[j]; //assign key
    int i=j-1; 

    while(i>=0 && A[i]>key) 
    {
      A[i+1] = A[i]; //if the next number is smaller then replace it with the current 
      i=i-1;
    }
    A[i+1]=key; //assign next number as current
  }
} 

int partition(int A[], int p, int r) //function to sort the random numbers with 'partition' part of quicksort 
{
  int x = A[r]; //assign x as A[r]
  int i = p -1; //starting value for i
  int a, b;

  for(int j=p; j <= r-1; ++j)
    {
      if (A[j] <= x)
        {
          i = i + 1; //exchange A[i] with A[j] until A[j] is less than x
          a = A[i];
          A[i] = A[j];
          A[j] = a;
        }
    }

  b = A[i+1]; //exchange A[i+1] with A[r] 
  A[i+1] = x;
  A[r] = b;

  return(i+1);
}

void quicksort(int A[], int p, int r) //function to sort the random numbers with 'partition' part of quicksort 
{
  if (p<r)
    {
      int q = partition(A, p, r); //define q as the the return value of function partition
      quicksort(A, p, q-1); //function call to itself
      quicksort(A, q+1, r); //function call to itself
    }
}


void merge(int A[], int p, int q, int r) //function to sort the random numbers with 'merge' part of quicksort
{
  const int n1 = q-p+1; //declare n1 and n2
  const int n2 = r-q;
 
  int leftarray[n1]; //declare left and right array
  int rightarray[n2];
  
  for(int i=0; i<n1; i++)
    {
      leftarray[i] = A[p+i]; //sort the numbers in left anf right array
    }
  for(int j=0; j<n2; j++)
    {
      rightarray[j] = A[q+j+1];
    }

  leftarray[n1] = std::numeric_limits<int>::max(); //declare leftarray and rightarray as infinity
  rightarray[n2] = std::numeric_limits<int>::max();

  int i=0; //initialize value of i and j again
  int j=0;

  for(int k=p; k<=r; k++)
    {
      if(leftarray[i]<=rightarray[j]) //if leftarray is bigger than rightarray, original array is leftarray
      {
        A[k]=leftarray[i]; 
        i=i+1;
      }
      else
      {
        A[k]=rightarray[j]; //else original array os rightarray
        j=j+1;
      }
    }
}

void mergesort(int A[], int p,int r) //function to sort the random numbers with mergesort sort
{
  if(p<r)
  {
    int q=(p+r)/2; //assign value to q
    mergesort(A,p,q); //function call to itself 
    mergesort(A,q+1, r); //function call to itself
    merge(A,p,q,r); //function call to 'merge' function
  }
}

void max_heapify (int A[], int i, int n) //function to sort the random array for 'max-heapity' part of heap-sort
{
  int l, r, largest;
  int a, b;

  l = 2*i + 1; //left and right child
  r = 2*i + 2;

  if ((l<=n)&&(A[l]>A[i]))
    {
      largest = l; //assign largest as l for A[l] less than A[i] and l less than or eual to n
    }
  else
    {
      largest = i; //else assign largest as i
    }

  if((r<=n)&&(A[r]>A[largest]))
    {
      largest = r; //assign largest as l for A[r] less than A[largest] and r less than or eual to n
    }

  if(largest != i)
    {
      a = A[i];
      b = A[largest]; //exchange A[i] and A[largest] if largest is not equal to i
      A[i] = b;
      A[largest] = a;
      max_heapify(A, largest, n); //function call within function itself
    }
}

void build_max_heap(int A[], int n) //function to sort the random array for 'build-max-heap' part of heap-sort
{
  for (int i = floor(n/2); i>=0; i--)
    {
      max_heapify(A, i, n); //for i equals n/2 until 0, call function max_heapify
    }
}

void heapsort(int A[], int n) //function to sort the random array using heap-sort
{
  int a, b;

  build_max_heap(A, n); //call build max heap

  for (int i=n; i>=1; i--)
    {
      a = A[0]; //exchange root with A[i]
      b = A[i];
      A[0] = b;
      A[i] = a;
      max_heapify(A, 0 , i-1); //call max heapify from the function
    }
}

int main ()
{
  for (long int i=10; i<= 1000000; i = i*10) //for loop to increase the size by 10 each time
    {     
      int* original_array = new int[i]; //define original array as dynamic array
      int* insertionsort_array = new int[i]; //define dynamic arrays for insertion sort
      int* quicksort_array = new int[i];//define dynamic arrays for quick sort
      int* mergesort_array = new int[i];//define dynamic arrays for merge sort
      int* heapsort_array = new int[i];//define dynamic arrays for heap sort
      int size, start, end;
      size = i;
      start = 0; //start from array element 0
      end = size-1; //end at size minus 1
      srand(time(0)); //function so that the random number generator generates different numbers every time
      random_number_generator(size); //function all to generate random numbers
      makearray(original_array, size);//function call to make original array
      
      ofstream inputfile; //declare inputfile as a ofstream
      inputfile.open("input.txt",fstream::in | fstream::out | fstream::app); //create and open a text file that will contain the unsorted numbers
      inputfile << endl << "******************************************************" << endl;
      inputfile << endl << "For size " << size << endl;
      inputfile << "----------------" << endl; 
      for(int k=0; k<size; k++)
      {
        inputfile<<original_array[k] <<" "; //send the unsorted array to inputfile
      }
      inputfile.close();

      for (int j=0; j<i; j++)
        {
          insertionsort_array[j] = original_array[j]; //assign insertionsort_array as the original array.
          quicksort_array[j] = original_array[j]; //assign quicksort_array as the original array.
          mergesort_array[j] = original_array[j]; //assign merrgesort_array as the original array.
          heapsort_array[j] = original_array[j]; //assign heapsort_array as the original array.
        }

      clock_t t1; //define t1 as of type clock
      float time1; //define time1 as afloat that stores the time
      cout << endl << "******************************************************" << endl; 
      cout << endl << "For size " << size << endl;
      cout << "----------------" << endl;
      
      t1 = clock(); //start clock
      insertion(insertionsort_array, end);
      ofstream insertionfile; //declare insertionfile as a ofstream
      insertionfile.open("insertion_sorted.txt",fstream::in | fstream::out | fstream::app); //create and open a text file that will contain the sorted numbers
      insertionfile << endl << "******************************************************" << endl;
      insertionfile << endl << "For size " << size << endl;
      insertionfile << "----------------" << endl; 
      for(int i=0; i<size; i++)
      {
        insertionfile<<insertionsort_array[i] <<" "; //send the sorted array to insertionsort_array.
      }
      insertionfile.close();	
      t1 = clock() - t1; //end clock
      time1 = ((float)t1)/CLOCKS_PER_SEC; //show time in seconds
  
      cout << endl << "for insertionsort" << endl; 
      cout << time1 << " seconds" << endl; //output time
      
      t1 = clock();
      quicksort(quicksort_array, start, end);
      ofstream quicksortfile;
      quicksortfile.open("quicksort_sorted.txt",fstream::in | fstream::out | fstream::app);
      quicksortfile << endl << "******************************************************" << endl;
      quicksortfile << endl << "For size " << size << endl;
      quicksortfile << "----------------" << endl;    
      for(int i=0; i<size; i++)
      {
        quicksortfile<<quicksort_array[i]<<" ";//send the sorted array to quicksort_array.
      } 
      quicksortfile.close();    

      t1 = clock() - t1;
      time1 = ((float)t1)/CLOCKS_PER_SEC;
      
      cout << endl << "for quicksort" << endl;
      cout << time1 << " seconds" << endl;
  
      t1 = clock();
      mergesort(mergesort_array, start, end);
      ofstream mergesortfile;
      mergesortfile.open("mergesort_sorted.txt",fstream::in | fstream::out | fstream::app);
      mergesortfile << endl << "******************************************************" << endl;
      mergesortfile << endl << "For size " << size << endl;
      mergesortfile << "----------------" << endl;    
      for(int i=0; i<size; i++)
      {
        mergesortfile<<mergesort_array[i]<<" ";//send the sorted array to mergesort_array.
      } 
      mergesortfile.close();    

      t1 = clock() - t1;
      time1 = ((float)t1)/CLOCKS_PER_SEC;
  
      cout << endl << "for mergesort" << endl;
      cout << time1 << " seconds" << endl;
  
      t1 = clock();
      heapsort(heapsort_array, end);
      ofstream heapsortfile;
      heapsortfile.open("heapsort_sorted.txt",fstream::in | fstream::out | fstream::app);
      heapsortfile << endl << "******************************************************" << endl;
      heapsortfile << endl << "For size " << size << endl;
      heapsortfile << "----------------" << endl;
      for(int i=0; i<size; i++)
      {
        heapsortfile<<quicksort_array[i]<<" ";//send the sorted array to heapsort_array.
      }
      heapsortfile.close();
      t1 = clock() - t1;
      time1 = ((float)t1)/CLOCKS_PER_SEC;
      
      cout << endl << "for heapsort" << endl;  

      cout << time1 << " seconds" << endl;
    } 
}
