/****************************************************************************
 * twople.cpp  --- JRogers, Apr/2008  --- CS256  Template Lab
 * implementation of typedef version of twople type as pairs: <string,int>
 * For documentation see twople.h
 ****************************************************************************/
#include "twople.h"

using namespace std;
namespace CS256_TemplateLab
{
  // Constructor
  template <class Left, class Right>
  twople<Left, Right>::twople(Left l, Right r) //Adhish: Added template class
                                               //to all twople, part 1
  {
    lft = l;
    rgt = r;
  }
    
  // Comparison operators

  //  operator <
  //   Preconditions: None
 template <class Left, class Right>
  bool operator<(const twople<Left, Right>& lpr, const twople<Left, Right>& rpr)
  {
    return (lpr.left()<rpr.left() ||
            (!(rpr.left()<lpr.left()) && lpr.right()<rpr.right()));
  }
  
  //  operator >
  //   Preconditions: None
 template <class Left, class Right>
  bool operator>(const twople<Left, Right>& lpr, const twople<Left, Right>& rpr) 
  { return rpr<lpr; }

  //  operator ==
  //   Preconditions: None
 template <class Left, class Right>
  bool operator==(const twople<Left, Right>& lpr, const twople<Left, Right>& rpr)
  {
    return (lpr.left()==rpr.left() && lpr.right()==rpr.right());
  }
  
  //  operator !=
  //   Preconditions: None
 template <class Left, class Right>
  bool operator!=(const twople<Left, Right> lpr, const twople<Left, Right> rpr) 
  { return !(lpr==rpr); }


  // I/O operators

  // Insertion operator
  //   Preconditions: None
 template <class Left, class Right>
  std::ostream& operator<<(std::ostream& str, const twople<Left, Right>& pair)
  {
    return str << pair.left() << " " << pair.right();
  }

  // Extraction operator
  //   Preconditions: None
 template <class Left, class Right>
  std::istream& operator>>(std::istream& str, twople<Left, Right>& pair)
    {
      str >> (pair.left());
      str >> (pair.right());
      return str;
    }
}
