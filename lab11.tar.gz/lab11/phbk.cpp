/****************************************************************************
 * phbk.cpp  --- JRogers, Apr/2008  --- CS256  Template Lab
 * Implementation of Phonebook class, typedef version
 * See phbk.h for docmentation
 *
 * Namespace: CS256_TemplateLab
 ****************************************************************************/
#include "phbk.h"

using namespace std;

namespace CS256_TemplateLab
{
  // const_iterator lookup(Name name)
  //   return iterator to (first) entry for name
  //  Preconditions: None
  phbk::const_iterator phbk::lookup(phbk::Name name) const
  {
    vector<twople<phbk::Name, phbk::Number> >::const_iterator i = phlist.begin(); //Adhish:
                                                                                  //changed
                                                                                  //type
                                                                                  //to
                                                                                  //template,
                                                                                  //Part 1
                                                                            
    while (i != phlist.end() && (*i).left()!=name)
      ++i;
    return i;
  }
  
  // iterator lookup(Name name)
  //  return iterator to (first) entry for name
  //  Preconditions: None
  phbk::iterator phbk::lookup(phbk::Name name)
  {
    vector<twople<phbk::Name, phbk::Number> >::iterator i = phlist.begin(); //Adhish
                                                                            //:
                                                                            //Part 1
    while (i != phlist.end() && (*i).left()!=name)
      ++i;
    return i;
  }
  
  // Insertion operator
  //  Preconditions: None
  std::ostream& operator<<(ostream& str, phbk book)
  {
    for(vector<twople<phbk::Name, phbk::Number> >::const_iterator i = (book.phlist).begin();
        i != (book.phlist).end();
        ++i)
      str << *i << '\n';
    return str;
  }
  
}
