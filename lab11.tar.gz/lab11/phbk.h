/****************************************************************************
 * phbk.h  --- JRogers, Apr/2008  --- CS256  Template Lab
 * typedef version
 *
 * phbk is a Phonebook implementation based on twople
 *  A phbk is an ordered collection of twoples of <Name,Number>
 *   Where Name is the twople::Left type and Number is the twople::Right type
 *
 * TYPEDEFS:
 *  Name --- name type
 *  Number --- number type
 *  iterator --- iterator into collection
 *  const_iterator --- iterator into const collection
 *
 * CONSTANT MEMBER FUNCTIONS
 *  iterator end() --- return past_end iterator
 *   Preconditions: none
 *  const_iterator lookup(Name name)
 *    return iterator to (first) entry for name
 *    returns phbk.end() if not found
 *   Preconditions: none
 *  size_t size()  -- return number of entries
 *   Preconditions: none
 *
 * MODIFICATION MEMBER FUNCTIONS
 *  void add_entry(Name name, Number number)
 *    add entry for <name, number>
 *   Preconditions: none
 *  iterator lookup(Name name)
 *    return iterator to (first) entry for name
 *    returns phbk.end() if not found
 *   Preconditions: none
 *  void sort()  --  sort entries
 *   Preconditions: none
 *
 * NON-MEMBER FUNCTIONS
 *  Insertion operator
 *    ostream& operator<<(ostream& str, phbk book)
 *   Preconditions: none
 *
 * VALUE SEMANTICS
 *  Assignment operator and copy constructor can be used with phbk
 *
 * LIBRARIES:
 *  twople.h  --- for twople
 *  string, vector, iostream
 *  algorithm --- for vector::sort()
 *
 * Namespace: CS256_TemplateLab
 ****************************************************************************/
#ifndef PHBK_H
#define PHBK_H

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include "twople.h"

namespace CS256_TemplateLab
{

  class phbk
  {
  public:
    // TYPEDEFS
    //  Name type
    typedef twople<std::string,std::string> Name; //Adhish: Part 2, changed the
                                                  //typw to incorporate forename
                                                  //and sirname 
    //  Number type
      typedef int Number;
    //  iterators
    typedef std::vector<twople<Name, Number> >::iterator iterator; //Adhish:
                                                                   //Template
                                                                   //class
                                                                   //<Name,
                                                                   //Number>,
                                                                   //Part 1
    typedef std::vector<twople<Name, Number> >::const_iterator const_iterator;

    // Constructor
    phbk() {};
    
    // Constant member functions

    // iterator end()  -- return past_end iterator
    iterator end() {return phlist.end();}

    // const_iterator lookup(Name name)
    //   return iterator to (first) entry for name
    const_iterator lookup(Name name) const;
    
    // size_t size()  -- return number of entries
    std::size_t size() const { return phlist.size(); }

    // Modification member functions

    // void add_entry(Name name, Number number)
    //  add entry for <name, number>
    void add_entry(Name name, Number number)
    {
      phlist.push_back(twople<Name, Number>(name,number));
    }
    
    // iterator lookup(Name name)
    //  return iterator to (first) entry for name
    iterator lookup(Name name);
    
    // void sort()  --  sort entries
    void sort() { std::sort(phlist.begin(),phlist.end()); }

    // Friend functions

    // Insertion operator
    friend  std::ostream& operator<<(std::ostream& str, phbk book);
  
  private:
    std::vector<twople<Name, Number> > phlist; //Adhish: Part 1
  };
  
}
#endif // PHBK_H
