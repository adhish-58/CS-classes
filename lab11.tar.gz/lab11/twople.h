/****************************************************************************
 * twople.h  --- JRogers, Apr/2008  --- CS256  Template Lab  
 * typedef version of twople type as pairs: <string,int>
 *
 * TYPEDEFS:
 *  Left --- type of left component
 *  Right --- type of right component
 *
 * CONSTANT MEMBER FUNCTIONS
 * const Left& left() --- return reference to left component
 * const Right& right() --- return reference to right component
 *
 * MODIFICATION MEMBER FUNCTIONS
 * Left& left() --- return reference to left component
 *  Preconditions: none
 * Right& right() --- return reference to right component
 *  Preconditions: none
 *
 * NON-MEMBER FUNCTIONS
 *  Comparison operators
 *   bool operator<(const twople& lpr, const twople& rpr)
 *     Preconditions: none
 *   bool operator>(const twople& lpr, const twople& rpr)
 *     Preconditions: none
 *   bool operator==(const twople& lpr, const twople& rpr)
 *     Preconditions: none
 *   bool operator!=(const twople lpr, const twople rpr)
 *     Preconditions: none
 *  I/O operators
 *   ostream& operator<<(ostream& str, const twople& pair)
 *     Preconditions: none
 *   istream& operator>>(istream& str, twople& pair)
 *     Preconditions: none
 * 
 * VALUE SEMANTICS
 *  Assignment operator and copy constructor can be used with twople
 *
 * Libraries:
 *  iostream
 *
 * Namespace: CS256_TemplateLab
 ****************************************************************************/
#ifndef TWOPLE_H
#define TWOPLE_H

#include<iostream>

namespace CS256_TemplateLab
{
  template <class Left, class Right>
  class twople
  {
  public:
    // typedefs

    // Constructor
    twople<Left, Right>(Left l=Left(), Right r=Right()); //Adhish: Defined
                                                         //template class, Part 1
    
    // Constant member functions
    const Left& left() const { return lft; }
    const Right& right() const { return rgt; }

    // Modification member functions
    Left& left() { return lft; }
    Right& right() { return rgt; }

  private:
    Left lft;   // Left component
    Right rgt;  // Right component
  };

  // Non-member functions
  
  // Comparison operators
  template <class Left, class Right> //Adhish: Defined Template class, Part 1 
  bool operator<(const twople<Left, Right>& lpr, const twople<Left, Right>& rpr);

  template <class Left, class Right>
  bool operator>(const twople<Left, Right>& lpr, const twople<Left, Right>& rpr);

  template <class Left, class Right>
  bool operator==(const twople<Left, Right>& lpr, const twople<Left, Right>& rpr);

template <class Left, class Right>
  bool operator!=(const twople<Left, Right> lpr, const twople<Left, Right> rpr);

  // I/O operators
 template <class Left, class Right>
  std::ostream& operator<<(std::ostream& str, const twople<Left, Right>& pair);
 template <class Left, class Right>
  std::istream& operator>>(std::istream& str, twople<Left, Right>& pair);

}
#include "twople.cpp" // Adhish: Part 1
#endif
