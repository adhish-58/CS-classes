/****************************************************************************
 * pbdriver.cpp  --- JRogers, Apr/2008  --- CS256  Template Lab             *
 * Driver for phbk/twople                                                   *
 * Commands:                                                                *
 *   i --- insert: Calls phbk::add_entry(twople)                            *
 *   l --- lookup: Calls phbk::lookup(Name)                                 *
 *   p --- print:  Prints out contents in current order                     *
 *   s --- sort:   Calls phbk::sort()                                       *
 *   ? --- menu:   Lists commands                                           *
 *   q --- quit:   Exit                                                     *
 *                                                                          *
 * Libraries:                                                               *
 *  phbk.h --- Phonebook type                                               *
 *  twople.h --- twople type (included from phbk.h)                         *
 *  iostream, string                                                        *
 ****************************************************************************/
#include "phbk.h"
#include <iostream>
#include <string>

using namespace std;
using namespace CS256_TemplateLab;

// Print menu
void menu();

int main()
{
  phbk book;                         // Phonebook under test
  char command('\0');                // User command input

  menu();

  while (cin && command != 'q')
    {
      cout << "There are " << book.size() << " entries in book\n";
      cout << "Command: ";
      cin >> command;

      phbk::Name name;               // user name input
      phbk::Number number;           // user number input
      phbk::iterator entry;          // iterator pointing to entry

      switch (command)
        {
        case 'i': 
          cout << "Enter name and number: ";
          cin >> name;
          cin >> number;
          book.add_entry(name, number);
          break;
        case 'l' :
          cout << "Enter name: ";
          cin >> name;
          entry=book.lookup(name);
          if (entry != book.end())
            cout << *entry << endl;
          else
            cout << name << ": Not found" << endl;
          break;
        case 'p':
          cout << "Book:\n" 
               << book 
               << endl;
          break;
        case '?':
          menu();
          break;
        case 's':
          book.sort();
        }
    }
}

void menu()
{
  cout << "Commands:\n\t i --- insert\n\t l --- lookup\n\t p --- print\n\t"
       << " s --- sort\n\t ? --- menu\n\t q --- quit" << endl;
}
